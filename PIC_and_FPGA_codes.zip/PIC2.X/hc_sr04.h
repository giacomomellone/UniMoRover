//RB4 and RB5 as Input PIN (ECHO), RB0 and RB1 as Output pin (Trigger))
#define ECHO1       PORTBbits.RB4
#define ECHO2       PORTBbits.RB5
#define TRIG1       LATBbits.LB0
#define TRIG2       LATBbits.LB1

